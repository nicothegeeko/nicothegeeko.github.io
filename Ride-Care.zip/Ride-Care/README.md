# Ride-Care
Ride-Care Project by Nico Flicker, Therese Pacete, Tom Miller, and Yen La
